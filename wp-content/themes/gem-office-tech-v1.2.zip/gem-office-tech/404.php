<?php get_header(); ?>

<h2>Error 404 Page</h2>

<p>Oops, this page could not be found.</p>

<p><a href="<?php bloginfo( 'url' ); ?>">Return home</a></p>

<?php get_footer();