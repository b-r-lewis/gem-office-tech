<?php 

	/**
	 * Template Name: Verticals
	 */

get_header(); ?>

<div class="main-content">
	
</div>

<?php get_footer();