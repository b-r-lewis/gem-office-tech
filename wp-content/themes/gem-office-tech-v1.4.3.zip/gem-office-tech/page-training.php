<?php 

	/**
	 * Template Name: Training
	 */

get_header(); ?>

<div class="main-content">

</div>

<?php get_footer();