<?php 

	/**
	 * Template Name: GEM Cares
	 */

	get_header(); the_post();
?>

<div class="main-content">
	
	<?php the_content(); ?>

</div>

<?php get_footer();