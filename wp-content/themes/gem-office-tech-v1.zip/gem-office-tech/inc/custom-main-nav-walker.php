<?php

class main_nav_walker extends Walker_Nav_Menu {}

}